//NodeTwo
// 引入头文件，包含项目中使用的各种硬件接口和功能模块的定义和配置
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_adc.h"
#include "queue.h"
#include "ZigBee.h"

// 定义用于存储紫外线强度值的全局变量
static uint16_t ultraviolet;
// 定义用于存储火焰检测状态的全局变量
static uint16_t FIRF;
static uint16_t FIRE;

// 定义一个用于临时存储ADC转换结果的变量
unsigned short value;

// 定义一个数据包数组，用于存储要发送给ZigBee模块的数据
uint8_t data[5]; 

// 主函数入口
int main(int arg, char *args[])
{
    // 设置GPIO引脚36为输入模式
    gpio_set_direction(GPIO_PIN_36, GPIO_Mode_In);
    // 初始化系统时钟和其他必要的系统配置
    SystemClockInit(); 
    // 初始化GPIO接口
    GPIOInit();        
    // 初始化OLED显示模块
    OLED_Init();
    // 初始化按键模块
    KEY_Init();
    // 开启中断控制器
    EnableInt();                                     
    // 初始化DL-LN3X模块，设置为发送节点，配置信道和网络地址
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id); 
    // 初始化循环队列
    Queue_Init(&Circular_queue);
    // 配置ADC通道6的引脚复用功能
    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0); 
    // 开启ADC模块的电源
    Adc_powerOn();                           
    // 打开ADC通道6，用于紫外线强度测量
    Adc_open(ADC_CHANNEL_I6);                
    // 初始化蜂鸣器模块
    BEEP_Init();
    // 初始化串口0，用于与外部设备通信
    Uart0_init(9600); 
    // 在OLED屏幕上显示初始信息
    OLED_Show_Str(0, 4, "Ie =     uW/cm2", 16);

    // 无限循环，用于实时监测和处理紫外线强度和火焰检测状态
    while (1)
    {
        // 测量ADC通道6的电压值，转换为紫外线强度
        ADC_value = Adc_Measure(ADC_CHANNEL_I6); 
        vol = ADC_value * 3300 / 4096;
        if (vol < 1000)
            vol = 1000;
        ultraviolet = 7917 * vol / 1000 - 7859;
        // 将紫外线强度值转换为字符串
        sprintf(str, "%4d", ultraviolet);          
        // 在OLED屏幕上显示紫外线强度值
        OLED_Show_Str(35, 4, str, 16);             
        delay_ms(10);

        // 检测GPIO引脚36的电平，用于火焰检测
        FIRF = gpio_get_pin(GPIO_PIN_36);
        if (FIRF == 1)
        {
            OLED_Show_Str(0, 0, "No Flame      ", 16);
            FIRE = 0;
            BEEP_OFF;
        }
        if (FIRF == 0)
        {
            OLED_Show_Str(0, 0, "Flaming        ", 16);
            FIRE = 1;
            BEEP_ON;
        }

        // 将紫外线强度值和火焰检测状态打包到数据数组中，准备发送
        data[0] = 0x03;
        data[1] = ultraviolet / 256;
        data[2] = ultraviolet % 256;
        data[3] = FIRE / 256;
        data[4] = FIRE % 256;
        // 延迟一段时间后，通过ZigBee模块发送数据
        delay_ms(333);
        DL_LN3X_Send(data, 5, ZIGBEE_RX_NODE);
    }
    return 0;
}