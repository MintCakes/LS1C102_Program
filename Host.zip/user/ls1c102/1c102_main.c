//Host
// 包含所需的头文件，这些头文件定义了硬件接口和其他功能
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ZigBee.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "UserGpio.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "queue.h"
#include "ls1x_clock.h"

// 定义用于指示的LED引脚
#define LED 20

// 定义用于存储传感器数据的全局变量
char str[50];
static uint16_t temp;
static uint16_t humi;
static uint16_t Flamegas;
static uint16_t Ie;
static uint16_t Flame1;
static uint16_t Flame2;
static uint16_t rain;

// 定义接收数据的状态变量和接收缓冲区
uint8_t received_data = 0;
uint8_t Read_Buffer[255]; // 设置接收缓冲数组
uint8_t Read_length;
uint8_t da = 0;
uint8_t arr[8] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

/**
 * 发送一个uint8_t类型的数组通过UART
 * @param data 要发送的数据数组
 * @param length 数据数组的长度
 */
void send_uint8_array(uint8_t *data, size_t length)
{
    for (size_t i = 0; i < length; i++)
    {
        UART_SendData(UART1, data[i]); // 发送数组中的每一个元素
    }
}

// 主函数
int main(int arg, char *args[])
{
    // 初始化系统时钟和GPIO
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置

    // 初始化OLED、蜂鸣器和其他设备
    OLED_Init();
    BEEP_Init();
    EnableInt(); // 开总中断
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id);
    Uart1_init(9600);
    Queue_Init(&Circular_queue);
    OLED_Show_Str(10, 0, "ZigBee Host", 16); // OLED显示界面
    delay_s(5);

    // 主循环
    while (1)
    {
        // 检查队列是否为空，如果不为空，则处理接收到的数据
        if (Queue_isEmpty(&Circular_queue) == 0) // 判断队列是否为空，即判断是否收到数据
        {
            Read_length = Queue_HadUse(&Circular_queue);           // 返回队列中数据的长度
            Queue_Read(&Circular_queue, Read_Buffer, Read_length); // 读取队列缓冲区的值到接收缓冲区

            // 根据接收到的数据类型，更新相应的传感器数据
            if (Read_Buffer[6] == 0x02)
            {
                temp = Read_Buffer[7] << 8 | Read_Buffer[8];
                humi = Read_Buffer[9] << 8 | Read_Buffer[10];
                Flamegas = Read_Buffer[11];
            }

            else if (Read_Buffer[6] == 0x03)
            {
                Ie = Read_Buffer[7] << 8 | Read_Buffer[8];
                Flame1 = Read_Buffer[9] << 8 | Read_Buffer[10];
            }

            else if (Read_Buffer[6] == 0x04)
            {
                rain = Read_Buffer[7] << 8 | Read_Buffer[8];
                Flame2 = Read_Buffer[9] << 8 | Read_Buffer[10];
            }

            // 准备数据数组并发送
            arr[0] = 0xAA;
            arr[1] = temp / 10;
            arr[2] = humi / 10;
            arr[3] = Flame1;
            arr[4] = Flame2;
            arr[5] = Flamegas;
            arr[6] = Ie;
            arr[7] = rain;
            arr[8] = 0xBB;
            send_uint8_array(arr, 9);
            memset(Read_Buffer, 0, 255); // 填充接收缓冲区为0
            delay_ms(500);
        }
        else
        {
            memset(Read_Buffer, 0, 255); // 填充接收缓冲区为0
        }
    }

    return 0;
}
