// NodeThree
// 包含头文件，初始化系统及相关模块
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"

#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_adc.h"
#include "queue.h"
#include "ZigBee.h"

// 定义LED、风扇及ADC相关引脚
#define LED 20
#define LED3_PIN GPIO_PIN_27
#define LED4_PIN GPIO_PIN_26
#define fan GPIO_PIN_37

// 定义用于显示的字符串及数据变量
char str[50];
unsigned short value;
uint8_t received_data = 0;
int time = 0;
int FIRE, rain;

uint8_t data[5]; // 数据包

// 主函数
int main(int arg, char *args[])
{
    // 初始化系统时钟、GPIO、OLED、中断、UART、ZigBee等模块
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt();        // 开总中断
    Uart0_init(115200); // 串口0初始化，io06 io07
    // Uart1_init(9600);
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id); // 设置为主机（接收端），设置信道为0x12，网络地址为0x0003
    Queue_Init(&Circular_queue);

    // 配置ADC相关引脚及初始化ADC
    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0); // 初始化ADC通道6引脚
    Adc_powerOn();                           // 打开ADC电源
    Adc_open(ADC_CHANNEL_I6);                // 开启ADC通道6
    gpio_set_direction(GPIO_PIN_36, GPIO_Mode_In);

    // OLED显示初始界面
    OLED_Show_Str(5, 16, "No liquid ", 16); // OLED显示界面

    // 检测液体和火焰，并通过ZigBee发送数据
    while (1)
    {
        // 检测是否有液体
        value = Adc_Measure(ADC_CHANNEL_I6); // ADC电压采集  单位：毫伏
        if (value >= 4095)
        {
            OLED_Show_Str(5, 0, "No liquid      ", 16);
            rain = 0;
        }
        else
        {
            OLED_Show_Str(5, 0, "liquid detected", 16);
            rain = 1;
        }

        // 检测是否有火焰
        int FIRF = gpio_get_pin(GPIO_PIN_36);
        if (FIRF == 1)
        {
            OLED_Show_Str(5, 3, "No Flame      ", 16);
            FIRE = 0;
            BEEP_OFF;
        }
        if (FIRF == 0)
        {
            OLED_Show_Str(5, 3, "Flaming        ", 16);
            FIRE = 1;
            BEEP_ON;
        }

        // 组装数据包并发送
        data[0] = 0x04;
        data[1] = rain / 256;
        data[2] = rain % 256;
        data[3] = FIRE / 256;
        data[4] = FIRE % 256;
        delay_ms(444);
        DL_LN3X_Send(data, 5, ZIGBEE_RX_NODE);
    }

    return 0;
}